/// <reference path="typings/jquery/jquery.d.ts" />
