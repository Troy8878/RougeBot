#########################
# Constants.rb
# Connor Hilarides
# Created 2014/09/07
# Copyright © 2015 DigiPen Institute of Technology, All Rights Reserved
#########################

CURRENT_LEVEL = GameLevelWrapper.new
