#########################
# Constants.rb
# Connor Hilarides
# Created 2014/09/07
#########################

CURRENT_LEVEL = GameLevelWrapper.new
