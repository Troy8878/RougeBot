#######################
# COMPNAMEComponent.rb
# YOURNAME
# Created 2015/DATEHERE
# Copyright © 2015 DigiPen Institute of Technology, All Rights Reserved
#######################

class COMPNAMEComponent < ComponentBase

  # Describe what goes in the json file
  serialized_input do |p|
  end

  def initialize(data)
    super data
  end

  register_component
end
