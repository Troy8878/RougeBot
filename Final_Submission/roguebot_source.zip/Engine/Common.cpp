/*********************************
 * Common.cpp
 * Connor Hilarides
 * Created 2014/08/07
 * Copyright � 2014 DigiPen Institute of Technology, All Rights Reserved
 *********************************/

#include "Common.h"
