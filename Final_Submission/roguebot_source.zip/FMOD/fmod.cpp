/*********************************
* fmod.cpp
* Troy
* Created 2014/09/26
*********************************/

/******************************************************************************/

#include "SoundSystem.h"
#include "fmod/fmod_errors.h"

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

SoundClass::SoundClass()
{
  // Create our system
  FMODresult = FMOD::System_Create(&SoundSystem);
  CheckResult(FMODresult == FMOD_OK);

  // Initialize FMOD
  FMODresult = SoundSystem->init(512, FMOD_INIT_NORMAL, 0);
  CheckResult(FMODresult == FMOD_OK);

  /*
  Set the user selected speaker mode.
  */
  FMODresult = FMOD_System_SetSpeakerMode(SoundSystem, speakermode);
  FMOD_ErrorString(FMODresult);
  if (caps & FMOD_CAPS_HARDWARE_EMULATED)
  {
    /* The user has the 'Acceleration' slider set to off! This is really bad
    for latency! You might want to warn the user about this. */
    FMODresult = FMOD_System_SetDSPBufferSize(SoundSystem, 1024, 10);
    FMOD_ErrorString(FMODresult);
  }
  FMODresult = FMOD_System_Init(SoundSystem, 100, FMOD_INIT_NORMAL, 0);
  if (FMODresult == FMOD_ERR_OUTPUT_CREATEBUFFER)
  {
    /*
    Ok, the speaker mode selected isn't supported by this soundcard. Switch it
    back to stereo...
    */
    FMODresult = FMOD_System_SetSpeakerMode(SoundSystem, FMOD_SPEAKERMODE_STEREO);
    FMOD_ErrorString(FMODresult);
    /*
    ... and re-init.
    */
    FMODresult = FMOD_System_Init(SoundSystem, 100, FMOD_INIT_NORMAL, 0);
  }
  FMOD_ErrorString(FMODresult);
}

SoundClass::~SoundClass()
{
  FMODresult = SoundSystem->release();
}

void SoundClass::Update()
{
  FMODresult = SoundSystem->update();
}

void SoundClass::CheckResult(bool isOkay)
{
  if (!isOkay)
  {
    std::cout << "FMOD error " << FMODresult << ":  " << FMOD_ErrorString(FMODresult);
    throw std::exception("FMOD init error.");
  }
}