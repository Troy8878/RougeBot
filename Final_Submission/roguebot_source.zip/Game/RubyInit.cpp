/*********************************
 * RubyInit.h
 * Connor Hilarides
 * Created 2014/05/29
 *********************************/

#include "mruby.h"
#include "mruby/compile.h"
#include "mruby/dump.h"
#include "mruby/proc.h"

extern "C"
{
  /*
  void mrb_init_mrblib(mrb_state *mrb)
  {
  }

  void mrb_init_mrbgems(mrb_state *mrb)
  {
  }

  void mrb_final_mrbgems(mrb_state *mrb)
  {
  }*/
}

