module Integral
  def div(other)
    self.divmod(other)[0]
  end
end
