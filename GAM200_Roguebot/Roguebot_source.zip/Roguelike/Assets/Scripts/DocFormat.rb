#Documentation Template#

#PLEASE COPY PASTE THIS TEMPLATE ON ALL RUBY FILES#

#########################
# FileName.rb
# Your Name
# Created Year/Month/Day
# Copyright © 2014 DigiPen Institute of Technology, All Rights Reserved
#########################

#Paste this on top of all classes!#

#########################Class Details##########################
# Enter a summary of the class here, as well as what it inherits
# and why.
#######################Property Details#########################
# List your properties and why they exist here.
################################################################

#Make sure to document/comment in code as well!#
#DO THIS OR JAKE WILL MURDER YOU!#
#Just kidding. Please just do it or you will make me sad panda.#

#Sincerely, 
#Jake Robsahm
#The person in charge of the Ruby

