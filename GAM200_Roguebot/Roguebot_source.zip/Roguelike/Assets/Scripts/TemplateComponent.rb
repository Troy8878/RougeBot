#######################
# COMPNAMEComponent.rb
# YOURNAME
# Created 2014/DATEHERE
# Copyright © 2014 DigiPen Institute of Technology, All Rights Reserved
#######################

class COMPNAMEComponent < ComponentBase
  def initialize(data)
    super data
  end

  register_component
end
