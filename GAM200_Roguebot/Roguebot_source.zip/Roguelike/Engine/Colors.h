/*********************************
 * Colors.h
 * Connor Hilarides
 * Created 2014/07/24
 * Copyright � 2014 DigiPen Institute of Technology, All Rights Reserved
 *********************************/

#pragma once

#include "Helpers\UseDirectX.h"

// ----------------------------------------------------------------------------

namespace Colors
{
  const math::Vector Transparent = {0, 0, 0, 0};
}

// ----------------------------------------------------------------------------