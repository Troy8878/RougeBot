/*********************************
* FloorComponent.h
* Avi Whitten-Vile
* Created 2014/09/11
*********************************/

#include "Common.h"


class FloorComponentFactory;

