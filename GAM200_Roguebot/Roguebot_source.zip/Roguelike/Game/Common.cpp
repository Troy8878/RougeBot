/*********************************
 * Common.cpp
 * Connor Hilarides
 * Created 2014/08/19
 * Copyright � 2014 DigiPen Institute of Technology, All Rights Reserved
 *********************************/

#include "Common.h"
