/*********************************
 * Common.h
 * Connor Hilarides
 * Created 2014/08/19
 * Copyright � 2014 DigiPen Institute of Technology, All Rights Reserved
 *********************************/

#pragma once

#include "Engine/Common.h"
#include "Engine/RubyWrappers.h"
#include "Roguelike.h"
