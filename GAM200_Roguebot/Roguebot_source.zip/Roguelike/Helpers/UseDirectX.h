/*********************************
 * UseDirectX.h
 * Connor Hilarides
 * Created 2014/06/24
 * Copyright � 2014 DigiPen Institute of Technology, All Rights Reserved
 *********************************/

#pragma once

#include "FixedWindows.h"
