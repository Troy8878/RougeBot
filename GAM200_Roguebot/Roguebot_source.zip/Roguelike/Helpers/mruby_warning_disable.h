
#pragma warning ( disable : 4127 )
#pragma warning ( disable : 4214 )
