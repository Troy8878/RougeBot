
#pragma warning ( default : 4127 )
#pragma warning ( default : 4214 )
