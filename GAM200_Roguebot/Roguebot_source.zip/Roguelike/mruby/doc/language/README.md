# Language

mruby is an implementation of the Ruby programming language.
These documents are describing the language features and libraries
which are provided together with mruby.

## Built-In Class and Modules

see *doc/language/Core.md*
